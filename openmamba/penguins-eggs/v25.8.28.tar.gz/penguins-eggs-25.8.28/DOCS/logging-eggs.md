# Instructions to logging eggs
Simply use:

* `sudo eggs produce|tee eggs-produce.log`
* `sudo eggs produce --theme neon|tee eggs-produce-theme-neon.log`

To have more output, it's possible to ad `--verbose`, ie:

* `sudo eggs produce --verbose|tee eggs-produce.log`
* `sudo eggs produce --theme neon --verbose|tee eggs-produce-theme-neon.log`
