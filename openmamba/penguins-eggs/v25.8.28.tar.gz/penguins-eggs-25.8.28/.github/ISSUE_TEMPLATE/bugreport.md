---
name: Bug Report
about: Help us improve Peguins Eggs!
title: '[BUG]:'
labels: 'bug'
assignees: ''

---

## The Bug and how to reproduce it

<!-- Provide details on the bug and the steps that must be taken to reproduce it. -->

## The version of Penguins Eggs

<!-- Provide the version number of penguins-eggs that you are using. Example: 10.0.59-1 -->

## Any other notes

<!-- Provide notes, screenshots, and other details that may not fit the above categories. -->
