---
name: Feature Request
about: Request a feature to be added to Penguins Eggs!
title: '[FEATURE]:'
labels: 'enhancement'
assignees: ''

---

## The feature

<!-- Provide details on the feature you want -->

## Any other notes

<!-- Provide notes, screenshots, and other details that may not fit the above categories. -->