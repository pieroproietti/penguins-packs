#!/usr/bin/sh
#
# read https://www.linux.it/~rubini/docs/init/init.html 
#
/usr/bin/eggs install --unattended
