# Devuan daedalus

It take all configuration of Debian buster