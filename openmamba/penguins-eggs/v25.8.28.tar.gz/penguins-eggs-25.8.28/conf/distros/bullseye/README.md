# Debian 11 bullseye

It take all configuration from Debian buster

Used by
- bullseye

ISSUES
* added 27 october 2021
