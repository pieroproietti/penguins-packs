# Debian 12 bookworm

It take all configuration from Debian buster

Used by
- bookworm

ISSUES
* added 27 october 2021
