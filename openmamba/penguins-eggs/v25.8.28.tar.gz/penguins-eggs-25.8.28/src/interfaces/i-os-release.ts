export default interface IOsRelease  {
         ID: string;
         VERSION_ID: string;
         VERSION_CODENAME: string;
}
