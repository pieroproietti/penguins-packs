# Krill classe

Le classi Prepare e Sequence sono state suddivise in diversi funzioni metodo nelle rispettive directory:
* prepare.d
* sequence.d

Questo permette una più agevole modifica del codice.
