declare module 'node-proxy-dhcpd'
